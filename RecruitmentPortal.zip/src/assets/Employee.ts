export const DataSource = [
    { 'name': 'Laxman', 'email': 'lxman123@gmail.com', 'ph_no': '7859568955', 'source': 'linkedin', skills: ['java', 'angular4'], location: 'hyderabad' },
    { 'name': 'Venkat', 'email': 'Venkat123@gmail.com', 'ph_no': '7859568933', 'source': 'linkedin', skills: ['javaScript', 'angular4'], location: 'hyderabad' },
    { 'name': 'Sumanth', 'email': 'Sumanth123@gmail.com', 'ph_no': '7859568977', 'source': 'github', skills: ['java', 'angular4', 'javaScript'], location: 'banglore' },
    { 'name': 'Vinay', 'email': 'Vinay123@gmail.com', 'ph_no': '7859568988', 'source': 'github', skills: ['java', 'angular4', 'spring'], location: 'pune' },
    { 'name': 'Ramakrishna', 'email': 'Ramakrishna123@gmail.com', 'ph_no': '7859568966', 'source': 'github', skills: ['angular1', 'spring'], location: 'pune' },
    { 'name': 'Shanmuk', 'email': 'Shanmuk123@gmail.com', 'ph_no': '7859568969', 'source': 'linkedin', skills: ['angular1', 'spring'], location: 'hyderabad' },
]