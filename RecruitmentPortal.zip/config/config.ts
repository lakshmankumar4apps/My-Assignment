export const valus ={
    "name":"nani"
}